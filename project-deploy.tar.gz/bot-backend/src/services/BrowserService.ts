import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { Browser, Page } from 'puppeteer';
import { CartItem } from '../types';

puppeteer.use(StealthPlugin());

export class BrowserService {
  private browser: Browser | null = null;
  private page: Page | null = null;

  async init() {
    console.log('Initializing browser...');
    
    // Check if running in Docker or locally
    const isDocker = process.env.NODE_ENV === 'production';
    const isHeadless = process.env.HEADLESS_BROWSER === 'true';
    
    const launchOptions: any = {
      headless: isDocker ? true : false, // Show browser window when running locally
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
        '--no-zygote',
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
        '--window-size=1920,1080',
        '--start-maximized'
      ],
      defaultViewport: null,
      ignoreDefaultArgs: ['--disable-extensions']
    };

    // Use system Chrome/Chromium when running locally
    if (!isDocker) {
      // Try to find Chrome/Chromium on Windows
      const possiblePaths = [
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files\\Google\\Chrome Beta\\Application\\chrome.exe',
        'C:\\Program Files\\Google\\Chrome Dev\\Application\\chrome.exe'
      ];
      
      for (const path of possiblePaths) {
        try {
          const fs = require('fs');
          if (fs.existsSync(path)) {
            launchOptions.executablePath = path;
            console.log(`Found Chrome at: ${path}`);
            break;
          }
        } catch (e) {
          // Continue searching
        }
      }
    } else {
      launchOptions.executablePath = process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium-browser';
    }
    
    this.browser = await puppeteer.launch(launchOptions);
    
    this.page = await this.browser.newPage();
    
    // Set viewport and user agent
    await this.page.setViewport({ width: 1920, height: 1080 });
    await this.page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36');
    
    // Set extra headers to avoid detection
    await this.page.setExtraHTTPHeaders({
      'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7'
    });
    
    // Enable stealth mode
    await this.page.evaluateOnNewDocument(() => {
      // Override the navigator.webdriver property
      Object.defineProperty(navigator, 'webdriver', {
        get: () => undefined
      });
    });
    
    console.log('Browser initialized successfully');
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
      this.page = null;
    }
  }

  async loginToWildberries(phone: string): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      console.log('Navigating to Wildberries login page...');
      await this.page.goto('https://www.wildberries.ru/security/login', { waitUntil: 'networkidle2' });
      
      // Wait for page to fully load
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Wait for phone input
      console.log('Looking for phone input field...');
      await this.page.waitForSelector('input[type="tel"]', { timeout: 10000 });
      
      // Clear the field first and then type
      const phoneInput = await this.page.$('input[type="tel"]');
      if (phoneInput) {
        await phoneInput.click({ clickCount: 3 });
        await phoneInput.type(phone);
      }
      
      // Wait a bit before clicking submit
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Try different selectors for the submit button
      console.log('Looking for submit button...');
      const submitSelectors = [
        'button[type="submit"]',
        'button.submit-btn',
        'button:has-text("Получить код")',
        'button:has-text("Продолжить")',
        'button.btn-main'
      ];
      
      let buttonClicked = false;
      for (const selector of submitSelectors) {
        try {
          const button = await this.page.$(selector);
          if (button) {
            console.log(`Found submit button with selector: ${selector}`);
            await button.click();
            buttonClicked = true;
            break;
          }
        } catch (e) {
          console.log(`Button selector ${selector} not found`);
        }
      }
      
      if (!buttonClicked) {
        // Try to press Enter as fallback
        console.log('Trying to submit with Enter key...');
        await this.page.keyboard.press('Enter');
      }
      
      // Wait for code input to appear
      console.log('Waiting for SMS code input...');
      await this.page.waitForSelector('input[inputmode="numeric"]', { timeout: 15000 });
      console.log('SMS code page reached successfully');
      
      return true;
    } catch (error) {
      console.error('Error during Wildberries login:', error);
      // Take screenshot for debugging
      try {
        await this.page.screenshot({ path: '/tmp/wildberries-login-error.png' });
        console.log('Screenshot saved to /tmp/wildberries-login-error.png');
      } catch (screenshotError) {
        console.error('Could not take screenshot:', screenshotError);
      }
      return false;
    }
  }

  async enterWildberriesCode(code: string): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      // Enter verification code
      await this.page.type('input[inputmode="numeric"]', code);
      
      // Wait for navigation after code entry
      await this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 10000 });
      
      // Check if logged in successfully
      const cookies = await this.page.cookies();
      return cookies.some(cookie => cookie.name.includes('WBToken'));
    } catch (error) {
      console.error('Error entering Wildberries code:', error);
      return false;
    }
  }

  async loginToOzon(phoneOrEmail: string): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      console.log('Navigating to Ozon login page...');
      await this.page.goto('https://www.ozon.ru/', { waitUntil: 'networkidle2' });
      
      // Wait a bit for page to load completely
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Try to find and click login button
      console.log('Looking for login button...');
      const loginSelectors = [
        '[data-widget="profileMenuAnonymous"]',
        'button:has-text("Войти")',
        '[aria-label*="Войти"]',
        '.tsBodyL:has-text("Войти")'
      ];
      
      let loginClicked = false;
      for (const selector of loginSelectors) {
        try {
          const element = await this.page.$(selector);
          if (element) {
            console.log(`Found login button with selector: ${selector}`);
            await element.click();
            loginClicked = true;
            break;
          }
        } catch (e) {
          console.log(`Selector ${selector} not found`);
        }
      }
      
      if (!loginClicked) {
        console.log('Could not find login button, trying direct navigation...');
        await this.page.goto('https://www.ozon.ru/my/main', { waitUntil: 'networkidle2' });
      }
      
      // Wait for login modal/page to appear
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Try different input selectors
      console.log('Looking for phone/email input...');
      const inputSelectors = [
        'input[type="tel"]',
        'input[type="text"]',
        'input[name="phone"]',
        'input[placeholder*="Телефон"]',
        'input[inputmode="tel"]'
      ];
      
      let inputFound = false;
      for (const selector of inputSelectors) {
        try {
          const element = await this.page.$(selector);
          if (element) {
            console.log(`Found input with selector: ${selector}`);
            await element.click();
            await element.type(phoneOrEmail);
            inputFound = true;
            break;
          }
        } catch (e) {
          console.log(`Input selector ${selector} not found`);
        }
      }
      
      if (!inputFound) {
        console.error('Could not find phone/email input field');
        return false;
      }
      
      // Try to find and click submit button
      console.log('Looking for submit button...');
      const submitSelectors = [
        'button[type="submit"]',
        'button:has-text("Получить код")',
        'button:has-text("Продолжить")',
        'button:has-text("Далее")'
      ];
      
      let submitClicked = false;
      for (const selector of submitSelectors) {
        try {
          const element = await this.page.$(selector);
          if (element) {
            console.log(`Found submit button with selector: ${selector}`);
            await element.click();
            submitClicked = true;
            break;
          }
        } catch (e) {
          console.log(`Submit selector ${selector} not found`);
        }
      }
      
      if (!submitClicked) {
        console.error('Could not find submit button');
        return false;
      }
      
      // Wait for code input
      console.log('Waiting for verification code input...');
      await this.page.waitForSelector('input[inputmode="numeric"]', { timeout: 15000 });
      console.log('Successfully reached verification code page');
      
      return true;
    } catch (error) {
      console.error('Error during Ozon login:', error);
      // Take a screenshot for debugging
      try {
        await this.page.screenshot({ path: '/tmp/ozon-login-error.png' });
        console.log('Screenshot saved to /tmp/ozon-login-error.png');
      } catch (screenshotError) {
        console.error('Could not take screenshot:', screenshotError);
      }
      return false;
    }
  }

  async enterOzonCode(code: string): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      // Enter verification code
      const codeInputs = await this.page.$$('input[inputmode="numeric"]');
      for (let i = 0; i < code.length && i < codeInputs.length; i++) {
        await codeInputs[i].type(code[i]);
      }
      
      // Wait for navigation
      await this.page.waitForNavigation({ waitUntil: 'networkidle2', timeout: 10000 });
      
      // Check if logged in
      const cookies = await this.page.cookies();
      return cookies.some(cookie => cookie.name.includes('__Secure-access-token'));
    } catch (error) {
      console.error('Error entering Ozon code:', error);
      return false;
    }
  }

  async addToCartWildberries(items: CartItem[]): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      for (const item of items) {
        // Navigate to product page
        await this.page.goto(`https://www.wildberries.ru/catalog/${item.product.sku}/detail.aspx`, { waitUntil: 'networkidle2' });
        
        // Set quantity if more than 1
        if (item.quantity > 1) {
          const quantityInput = await this.page.$('input[name="quantity"]');
          if (quantityInput) {
            await quantityInput.click({ clickCount: 3 });
            await quantityInput.type(item.quantity.toString());
          }
        }
        
        // Add to cart
        await this.page.click('button[data-link="class{basketContent}"]');
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
      
      return true;
    } catch (error) {
      console.error('Error adding to Wildberries cart:', error);
      return false;
    }
  }

  async addToCartOzon(items: CartItem[]): Promise<boolean> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      for (const item of items) {
        // Navigate to product page
        await this.page.goto(`https://www.ozon.ru/product/${item.product.sku}`, { waitUntil: 'networkidle2' });
        
        // Set quantity
        if (item.quantity > 1) {
          const plusButton = await this.page.$('button[aria-label="Добавить один товар"]');
          if (plusButton) {
            for (let i = 1; i < item.quantity; i++) {
              await plusButton.click();
              await new Promise(resolve => setTimeout(resolve, 500));
            }
          }
        }
        
        // Add to cart
        await this.page.click('button:has-text("Добавить в корзину")');
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
      
      return true;
    } catch (error) {
      console.error('Error adding to Ozon cart:', error);
      return false;
    }
  }

  async checkoutWildberries(): Promise<string | null> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      // Go to cart
      await this.page.goto('https://www.wildberries.ru/lk/basket', { waitUntil: 'networkidle2' });
      
      // Click checkout
      await this.page.click('button[data-link="class{checkoutButton}"]');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      
      // Complete checkout steps
      // Select delivery method if needed
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Confirm order
      await this.page.click('button[data-link="class{confirmOrder}"]');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      
      // Get order number
      const orderNumberElement = await this.page.$('.order-number');
      if (orderNumberElement) {
        const orderNumber = await orderNumberElement.evaluate(el => el.textContent);
        return orderNumber?.trim() || null;
      }
      
      return null;
    } catch (error) {
      console.error('Error during Wildberries checkout:', error);
      return null;
    }
  }

  async checkoutOzon(): Promise<string | null> {
    if (!this.page) throw new Error('Browser not initialized');

    try {
      // Go to cart
      await this.page.goto('https://www.ozon.ru/cart', { waitUntil: 'networkidle2' });
      
      // Click checkout
      await this.page.click('button:has-text("Перейти к оформлению")');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      
      // Wait for checkout page
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Confirm order
      await this.page.click('button:has-text("Подтвердить заказ")');
      await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
      
      // Get order number
      const orderNumberElement = await this.page.$('[data-widget="orderNumber"]');
      if (orderNumberElement) {
        const orderNumber = await orderNumberElement.evaluate(el => el.textContent);
        return orderNumber?.trim() || null;
      }
      
      return null;
    } catch (error) {
      console.error('Error during Ozon checkout:', error);
      return null;
    }
  }

  async saveCookies(): Promise<any[]> {
    if (!this.page) throw new Error('Browser not initialized');
    return await this.page.cookies();
  }

  async loadCookies(cookies: any[]) {
    if (!this.page) throw new Error('Browser not initialized');
    await this.page.setCookie(...cookies);
  }
}
