INSERT INTO products (store_id, wb_id, name, description, price, images, category, brand, rating, reviews_count, stock, in_stock, sku) VALUES 
('a2b3c4d5-e6f7-8901-2345-67890abcdeff', '12345', 'Test Product 1', 'This is a test description for product 1', 10.50, '{"image_url_1","image_url_2"}', 'Category 1', 'Brand 1', 4.5, 100, 50, true, 'SKU001'),
('a2b3c4d5-e6f7-8901-2345-67890abcdeff', '67890', 'Test Product 2', 'This is a test description for product 2', 15.00, '{"image_url_3","image_url_4"}', 'Category 2', 'Brand 2', 4.0, 200, 30, true, 'SKU002');
