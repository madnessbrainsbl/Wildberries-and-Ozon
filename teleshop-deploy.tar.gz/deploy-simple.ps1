# Простой скрипт развертывания для Windows
# Использует встроенные утилиты Windows

param(
    [string]$ServerHost = "teleshop.su",
    [string]$ServerUser = "root",
    [string]$ServerPath = "/var/www/teleshop"
)

Write-Host "🚀 Простое развертывание на сервер $ServerHost" -ForegroundColor Green

# Проверяем доступность сервера
Write-Host "📡 Проверка доступности сервера..." -ForegroundColor Yellow
try {
    $ping = Test-Connection -ComputerName $ServerHost -Count 2 -ErrorAction Stop
    Write-Host "✅ Сервер доступен (IP: $($ping[0].IPV4Address))" -ForegroundColor Green
} catch {
    Write-Host "❌ Сервер недоступен: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Создаем архив проекта (исключая ненужные файлы)
Write-Host "📦 Создание архива проекта..." -ForegroundColor Yellow

$excludeDirs = @("node_modules", ".git", "dist", ".vscode")
$projectFiles = Get-ChildItem -Path "." -Recurse | Where-Object {
    $exclude = $false
    foreach ($dir in $excludeDirs) {
        if ($_.FullName -like "*\$dir\*") {
            $exclude = $true
            break
        }
    }
    -not $exclude
}

# Создаем временную папку для архива
$tempDir = "$env:TEMP\teleshop-deploy"
if (Test-Path $tempDir) {
    Remove-Item $tempDir -Recurse -Force
}
New-Item -ItemType Directory -Path $tempDir | Out-Null

# Копируем нужные файлы
$projectFiles | ForEach-Object {
    $relativePath = $_.FullName.Replace((Get-Location).Path, "")
    $targetPath = Join-Path $tempDir $relativePath
    $targetDir = Split-Path $targetPath
    
    if (-not (Test-Path $targetDir)) {
        New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    }
    
    if (-not $_.PSIsContainer) {
        Copy-Item $_.FullName $targetPath
    }
}

# Создаем zip архив
$zipPath = "$env:TEMP\teleshop-project.zip"
if (Test-Path $zipPath) {
    Remove-Item $zipPath -Force
}

Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath -Force
Write-Host "✅ Архив создан: $zipPath" -ForegroundColor Green

# Показываем инструкции для ручного развертывания
Write-Host "`n📋 ИНСТРУКЦИИ ДЛЯ РАЗВЕРТЫВАНИЯ:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor White

Write-Host "`n1. 📤 Загрузите архив на сервер:" -ForegroundColor Yellow
Write-Host "   scp `"$zipPath`" ${ServerUser}@${ServerHost}:/tmp/project.zip" -ForegroundColor Gray

Write-Host "`n2. 🔐 Подключитесь к серверу:" -ForegroundColor Yellow
Write-Host "   ssh ${ServerUser}@${ServerHost}" -ForegroundColor Gray

Write-Host "`n3. 🔧 Выполните на сервере:" -ForegroundColor Yellow
$serverCommands = @"
# Подготовка сервера
apt update
curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh
systemctl start docker && systemctl enable docker
curl -L "https://github.com/docker/compose/releases/download/v2.20.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose && ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
apt install -y nginx unzip

# Распаковка проекта
mkdir -p $ServerPath
cd $ServerPath
unzip -o /tmp/project.zip
rm /tmp/project.zip

# Настройка окружения
cat > .env << 'EOF'
VITE_SUPABASE_URL=https://kzrafexlalajoirzugdj.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6cmFmZXhsYWxham9pcnp1Z2RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3Mjk0MDMsImV4cCI6MjA2OTMwNTQwM30.rrKmafrLhQWNk7bIC5kfoO5pcvEkzO2i_THc5_Ep3nk
TELEGRAM_BOT_TOKEN=8473502537:AAG1NAD5ryNZlx-FnEGGX9jlwqli7Zpq9Y0
EOF

# Настройка Nginx
cat > /etc/nginx/sites-available/teleshop.su << 'EOF'
server {
    listen 80;
    server_name teleshop.su www.teleshop.su;

    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /api/ {
        proxy_pass http://localhost:3002/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/teleshop.su /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx && systemctl enable nginx

# Запуск приложения
export VITE_SUPABASE_URL=https://kzrafexlalajoirzugdj.supabase.co
export VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6cmFmZXhsYWxham9pcnp1Z2RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3Mjk0MDMsImV4cCI6MjA2OTMwNTQwM30.rrKmafrLhQWNk7bIC5kfoO5pcvEkzO2i_THc5_Ep3nk
export TELEGRAM_BOT_TOKEN=8473502537:AAG1NAD5ryNZlx-FnEGGX9jlwqli7Zpq9Y0

docker-compose -f docker-compose.prod.yml down --remove-orphans || true
docker-compose -f docker-compose.prod.yml up -d --build

# Проверка статуса
docker-compose -f docker-compose.prod.yml ps
docker-compose -f docker-compose.prod.yml logs --tail=20
"@

Write-Host $serverCommands -ForegroundColor Gray

Write-Host "`n4. ✅ Проверка работы:" -ForegroundColor Yellow
Write-Host "   • Откройте http://teleshop.su" -ForegroundColor Gray
Write-Host "   • Проверьте статус: docker-compose -f docker-compose.prod.yml ps" -ForegroundColor Gray
Write-Host "   • Посмотрите логи: docker-compose -f docker-compose.prod.yml logs" -ForegroundColor Gray

Write-Host "`n📱 После развертывания отправьте /start боту в Telegram!" -ForegroundColor Green

# Предлагаем скопировать команды в буфер обмена
Write-Host "`n💡 Хотите скопировать команды в буфер обмена? (y/N)" -ForegroundColor Cyan
$response = Read-Host
if ($response -eq 'y' -or $response -eq 'Y') {
    $serverCommands | Set-Clipboard
    Write-Host "✅ Команды скопированы в буфер обмена!" -ForegroundColor Green
}

# Очистка временных файлов
Remove-Item $tempDir -Recurse -Force
Write-Host "`n🧹 Временные файлы очищены" -ForegroundColor Gray
Write-Host "🎉 Подготовка к развертыванию завершена!" -ForegroundColor Green
