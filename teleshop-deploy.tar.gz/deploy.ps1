# PowerShell deployment script for teleshop.su

Write-Host "Starting deployment to teleshop.su..." -ForegroundColor Green

# Server details
$SERVER_IP = "82.146.40.171"
$SERVER_USER = "root"
$SERVER_PASSWORD = "Alfa2000@"
$PROJECT_PATH = "/opt/teleshop"

# Create temporary script for server deployment
$deployScript = @'
#!/bin/bash
cd /opt/teleshop

# Install Docker if not already installed
if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    apt-get update
    apt-get install -y ca-certificates curl gnupg
    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    systemctl start docker
    systemctl enable docker
fi

# Install Docker Compose standalone if not already installed
if ! command -v docker-compose &> /dev/null; then
    echo "Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.24.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# Stop existing containers if any
echo "Stopping existing containers..."
docker-compose -f docker-compose.prod.yml down 2>/dev/null || true

# Build and start new containers
echo "Building and starting containers..."
docker-compose -f docker-compose.prod.yml up --build -d

# Check container status
echo "Checking container status..."
docker-compose -f docker-compose.prod.yml ps

# Configure firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 3002/tcp
ufw --force enable

echo "Deployment completed!"
'@

# Save deployment script
$deployScript | Out-File -FilePath "D:\project\server-deploy.sh" -Encoding UTF8

Write-Host "Deployment script created. Now you need to:" -ForegroundColor Yellow
Write-Host "1. Copy project files to server manually using SSH/SCP client" -ForegroundColor Yellow
Write-Host "2. Connect to server: ssh root@82.146.40.171" -ForegroundColor Yellow
Write-Host "3. Execute deployment commands on the server" -ForegroundColor Yellow
