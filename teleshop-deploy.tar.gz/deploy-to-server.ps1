# PowerShell deployment script for teleshop.su
# This script will deploy the project to the server

$ErrorActionPreference = "Stop"

# Server configuration
$SERVER_USER = "root"
$SERVER_HOST = "teleshop.su"
$SERVER_PATH = "/var/www/teleshop"
$PROJECT_DIR = "D:\project"

Write-Host "🚀 Starting deployment to teleshop.su..." -ForegroundColor Green

# First, let's create a simple deployment using scp and ssh
# We'll use WSL if available, otherwise provide manual instructions

try {
    # Check if WSL is available
    $wslAvailable = Get-Command wsl -ErrorAction SilentlyContinue
    
    if ($wslAvailable) {
        Write-Host "📦 Using WSL for deployment..." -ForegroundColor Yellow
        
        # Convert Windows path to WSL path
        $wslProjectPath = "/mnt/d/project"
        
        # Create deployment commands
        $deployCommands = @"
#!/bin/bash
set -e

echo "🚀 Starting deployment..."

# Create directory on server
ssh -o StrictHostKeyChecking=no ${SERVER_USER}@${SERVER_HOST} "mkdir -p ${SERVER_PATH}"

# Copy project files
echo "📤 Copying files to server..."
rsync -avz --exclude=node_modules --exclude=.git --exclude=dist ${wslProjectPath}/ ${SERVER_USER}@${SERVER_HOST}:${SERVER_PATH}/

# Install Docker and dependencies on server
echo "🐳 Setting up server environment..."
ssh ${SERVER_USER}@${SERVER_HOST} '
# Update system
apt update

# Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    systemctl start docker
    systemctl enable docker
fi

# Install Docker Compose if not present
if ! command -v docker-compose &> /dev/null; then
    echo "Installing Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.20.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
fi

# Install Nginx if not present
if ! command -v nginx &> /dev/null; then
    echo "Installing Nginx..."
    apt install -y nginx
fi
'

# Create environment file on server
echo "🔧 Creating environment file..."
ssh ${SERVER_USER}@${SERVER_HOST} "cat > ${SERVER_PATH}/.env << 'EOF'
VITE_SUPABASE_URL=https://kzrafexlalajoirzugdj.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6cmFmZXhsYWxham9pcnp1Z2RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3Mjk0MDMsImV4cCI6MjA2OTMwNTQwM30.rrKmafrLhQWNk7bIC5kfoO5pcvEkzO2i_THc5_Ep3nk
TELEGRAM_BOT_TOKEN=8473502537:AAG1NAD5ryNZlx-FnEGGX9jlwqli7Zpq9Y0
EOF"

# Stop existing containers and start new ones
echo "🏗️ Building and starting application..."
ssh ${SERVER_USER}@${SERVER_HOST} "
cd ${SERVER_PATH}
docker-compose -f docker-compose.prod.yml down --remove-orphans || true
export VITE_SUPABASE_URL=https://kzrafexlalajoirzugdj.supabase.co
export VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6cmFmZXhsYWxham9pcnp1Z2RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3Mjk0MDMsImV4cCI6MjA2OTMwNTQwM30.rrKmafrLhQWNk7bIC5kfoO5pcvEkzO2i_THc5_Ep3nk
export TELEGRAM_BOT_TOKEN=8473502537:AAG1NAD5ryNZlx-FnEGGX9jlwqli7Zpq9Y0
docker-compose -f docker-compose.prod.yml up -d --build
"

# Configure Nginx
echo "🌐 Configuring Nginx..."
ssh ${SERVER_USER}@${SERVER_HOST} "
cat > /etc/nginx/sites-available/teleshop.su << 'EOF'
server {
    listen 80;
    server_name teleshop.su www.teleshop.su;

    location / {
        proxy_pass http://localhost:80;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /api/ {
        proxy_pass http://localhost:3002/;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

ln -sf /etc/nginx/sites-available/teleshop.su /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
systemctl enable nginx
"

# Check status
echo "✅ Checking deployment status..."
ssh ${SERVER_USER}@${SERVER_HOST} "
cd ${SERVER_PATH}
echo '=== Container Status ==='
docker-compose -f docker-compose.prod.yml ps
echo
echo '=== Logs ==='
docker-compose -f docker-compose.prod.yml logs --tail=10
"

echo "🎉 Deployment completed!"
"@

        # Save the script and execute it
        $deployScript = "$PROJECT_DIR\deploy-wsl.sh"
        $deployCommands | Out-File -FilePath $deployScript -Encoding UTF8
        
        # Make script executable and run it
        wsl chmod +x /mnt/d/project/deploy-wsl.sh
        wsl /mnt/d/project/deploy-wsl.sh
        
    } else {
        Write-Host "❌ WSL not available. Please install Windows Subsystem for Linux or use manual deployment." -ForegroundColor Red
        Write-Host "Manual deployment steps:" -ForegroundColor Yellow
        Write-Host "1. Install SSH client (OpenSSH)" -ForegroundColor White
        Write-Host "2. Copy project files to server" -ForegroundColor White
        Write-Host "3. Run Docker commands on server" -ForegroundColor White
        
        # Let's try using built-in SSH if available (Windows 10+)
        $sshAvailable = Get-Command ssh -ErrorAction SilentlyContinue
        if ($sshAvailable) {
            Write-Host "📡 Found SSH client, attempting direct deployment..." -ForegroundColor Green
            
            # Create a simple deployment script that we'll copy to server
            $simpleDeployScript = @"
#!/bin/bash
cd /var/www/teleshop
echo 'Building application...'
docker-compose -f docker-compose.prod.yml down || true
export VITE_SUPABASE_URL=https://kzrafexlalajoirzugdj.supabase.co
export VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt6cmFmZXhsYWxham9pcnp1Z2RqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTM3Mjk0MDMsImV4cCI6MjA2OTMwNTQwM30.rrKmafrLhQWNk7bIC5kfoO5pcvEkzO2i_THc5_Ep3nk
export TELEGRAM_BOT_TOKEN=8473502537:AAG1NAD5ryNZlx-FnEGGX9jlwqli7Zpq9Y0
docker-compose -f docker-compose.prod.yml up -d --build
echo 'Deployment completed!'
docker-compose -f docker-compose.prod.yml ps
"@
            
            $simpleDeployScript | Out-File -FilePath "$PROJECT_DIR\server-deploy.sh" -Encoding UTF8
            
            Write-Host "Manual deployment instructions:" -ForegroundColor Cyan
            Write-Host "1. Copy files to server:" -ForegroundColor White
            Write-Host "   scp -r * root@teleshop.su:/var/www/teleshop/" -ForegroundColor Gray
            Write-Host "2. SSH to server and run deployment:" -ForegroundColor White
            Write-Host "   ssh root@teleshop.su" -ForegroundColor Gray
            Write-Host "   bash /var/www/teleshop/server-deploy.sh" -ForegroundColor Gray
        }
    }
} catch {
    Write-Host "❌ Error during deployment: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Let's try a simpler approach..." -ForegroundColor Yellow
}

Write-Host "`n📋 Next steps if automatic deployment failed:" -ForegroundColor Cyan
Write-Host "1. Ensure you have SSH access to root@teleshop.su" -ForegroundColor White
Write-Host "2. Copy project files to server manually" -ForegroundColor White
Write-Host "3. Install Docker and Docker Compose on server" -ForegroundColor White
Write-Host "4. Run docker-compose -f docker-compose.prod.yml up -d --build" -ForegroundColor White
