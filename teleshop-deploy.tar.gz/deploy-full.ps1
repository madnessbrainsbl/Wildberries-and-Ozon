# Complete deployment script for teleshop.su
$ServerIP = "54.38.155.8"
$ServerUser = "root"
$ServerPassword = "Alfa2000@"
$ProjectDir = "/opt/teleshop"

Write-Host "🚀 Starting full deployment to teleshop.su..." -ForegroundColor Green

# Create secure string for password
$SecurePassword = ConvertTo-SecureString $ServerPassword -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($ServerUser, $SecurePassword)

# Install required modules
if (!(Get-Module -ListAvailable -Name Posh-SSH)) {
    Write-Host "📦 Installing Posh-SSH module..." -ForegroundColor Yellow
    Install-Module -Name Posh-SSH -Force -Scope CurrentUser
}

Import-Module Posh-SSH

# Create SSH session
Write-Host "🔐 Connecting to server $ServerIP..." -ForegroundColor Yellow
$SSHSession = New-SSHSession -ComputerName $ServerIP -Credential $Credential -AcceptKey -Force

if (!$SSHSession) {
    Write-Host "❌ Failed to connect to server!" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Connected successfully!" -ForegroundColor Green

try {
    # Create project directory
    Write-Host "📁 Creating project directory..." -ForegroundColor Yellow
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "mkdir -p $ProjectDir"
    
    # Install Docker Compose (modern version)
    Write-Host "🐳 Installing Docker Compose..." -ForegroundColor Yellow
    $dockerComposeInstall = @"
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-`$(uname -s)-`$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
"@
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command $dockerComposeInstall -TimeOut 120
    
    # Create SFTP session for file transfer
    Write-Host "📤 Creating SFTP session for file transfer..." -ForegroundColor Yellow
    $SFTPSession = New-SFTPSession -ComputerName $ServerIP -Credential $Credential -AcceptKey -Force
    
    if ($SFTPSession) {
        Write-Host "📂 Uploading project files..." -ForegroundColor Yellow
        
        # Upload all necessary files
        $filesToUpload = @(
            "docker-compose.prod.yml",
            ".env",
            "bot-backend",
            "nginx", 
            "tunnel",
            "Dockerfile",
            "package.json",
            "vite.config.ts",
            "tsconfig.json",
            "src",
            "public",
            "index.html"
        )
        
        foreach ($file in $filesToUpload) {
            if (Test-Path $file) {
                Write-Host "📄 Uploading $file..." -ForegroundColor Cyan
                if (Test-Path $file -PathType Container) {
                    # Directory - upload recursively
                    Set-SFTPFolder -SessionId $SFTPSession.SessionId -LocalFolder $file -RemoteFolder "$ProjectDir/$file" -Overwrite
                } else {
                    # File - upload directly
                    Set-SFTPFile -SessionId $SFTPSession.SessionId -LocalFile $file -RemotePath "$ProjectDir/$file" -Overwrite
                }
            }
        }
        
        Write-Host "✅ Files uploaded successfully!" -ForegroundColor Green
        Remove-SFTPSession -SessionId $SFTPSession.SessionId
    }
    
    # Deploy application
    Write-Host "🏗️ Deploying application..." -ForegroundColor Yellow
    
    $deployCommands = @"
cd $ProjectDir
echo "Stopping existing containers..."
docker-compose -f docker-compose.prod.yml down || true
echo "Building and starting new containers..."
docker-compose -f docker-compose.prod.yml up --build -d
echo "Checking container status..."
docker-compose -f docker-compose.prod.yml ps
"@
    
    $result = Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command $deployCommands -TimeOut 600
    Write-Host $result.Output -ForegroundColor White
    
    if ($result.ExitStatus -eq 0) {
        Write-Host "✅ Application deployed successfully!" -ForegroundColor Green
        Write-Host "🌐 Your application should be available at: https://teleshop.su" -ForegroundColor Cyan
        
        # Check container status
        Write-Host "📊 Checking container status..." -ForegroundColor Yellow
        $statusResult = Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "cd $ProjectDir && docker-compose -f docker-compose.prod.yml ps"
        Write-Host $statusResult.Output -ForegroundColor White
        
        # Show logs
        Write-Host "📋 Recent logs:" -ForegroundColor Yellow
        $logsResult = Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "cd $ProjectDir && docker-compose -f docker-compose.prod.yml logs --tail=10"
        Write-Host $logsResult.Output -ForegroundColor Gray
        
    } else {
        Write-Host "❌ Deployment failed!" -ForegroundColor Red
        Write-Host $result.Output -ForegroundColor Red
    }
    
} catch {
    Write-Host "❌ Error during deployment: $_" -ForegroundColor Red
} finally {
    # Close SSH session
    Remove-SSHSession -SessionId $SSHSession.SessionId
}

Write-Host "🎯 Deployment process completed!" -ForegroundColor Green
Write-Host "📝 Next steps:" -ForegroundColor Yellow
Write-Host "1. ✅ Check if your app is running at https://teleshop.su" -ForegroundColor White
Write-Host "2. 🔒 Setup SSL certificate if needed" -ForegroundColor White  
Write-Host "3. 🤖 Test your Telegram bot functionality" -ForegroundColor White
