import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          telegram_id: number;
          username: string | null;
          first_name: string | null;
          last_name: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          telegram_id: number;
          username?: string | null;
          first_name?: string | null;
          last_name?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          telegram_id?: number;
          username?: string | null;
          first_name?: string | null;
          last_name?: string | null;
          created_at?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          user_id: string;
          marketplace: 'wildberries' | 'ozon';
          marketplace_order_id: string | null;
          status: 'pending' | 'processing' | 'completed' | 'failed';
          total_amount: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          marketplace: 'wildberries' | 'ozon';
          marketplace_order_id?: string | null;
          status?: 'pending' | 'processing' | 'completed' | 'failed';
          total_amount: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          marketplace?: 'wildberries' | 'ozon';
          marketplace_order_id?: string | null;
          status?: 'pending' | 'processing' | 'completed' | 'failed';
          total_amount?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string;
          quantity: number;
          price: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          order_id: string;
          product_id: string;
          quantity: number;
          price: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          order_id?: string;
          product_id?: string;
          quantity?: number;
          price?: number;
          created_at?: string;
        };
      };
      marketplace_accounts: {
        Row: {
          id: string;
          user_id: string;
          marketplace: 'wildberries' | 'ozon';
          phone: string | null;
          email: string | null;
          is_authenticated: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          marketplace: 'wildberries' | 'ozon';
          phone?: string | null;
          email?: string | null;
          is_authenticated?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          marketplace?: 'wildberries' | 'ozon';
          phone?: string | null;
          email?: string | null;
          is_authenticated?: boolean;
          created_at?: string;
        };
      };
    };
  };
}
