import TelegramBot from 'node-telegram-bot-api';
import { OrderService } from '../services/OrderService';
let BrowserService;

if (process.env.DISABLE_BROWSER === 'true') {
  console.log('Using stub BrowserService for production environment');
  BrowserService = require('../services/BrowserService.prod').BrowserService;
} else {
  BrowserService = require('../services/BrowserService').BrowserService;
}
import { supabase } from '../utils/supabase';
import { CartItem, User, AuthSession } from '../types';

export class BotController {
  private bot: TelegramBot;
  private orderService: OrderService;
  private browserService: BrowserService;
  private authSessions: Map<number, AuthSession> = new Map();
  private userCarts: Map<number, CartItem[]> = new Map();

  constructor(token: string) {
    // Configure bot with polling options to avoid conflicts
    this.bot = new TelegramBot(token, { 
      polling: {
        interval: 300,
        autoStart: true,
        params: {
          timeout: 10
        }
      }
    });
    
    this.orderService = new OrderService();
    this.browserService = new BrowserService();
    
    // Handle polling errors
    this.bot.on('polling_error', (error: any) => {
      console.error('Polling error:', error);
      if (error.code === 'ETELEGRAM' && error.message?.includes('409')) {
        console.log('Another instance is running. Stopping polling...');
        this.bot.stopPolling();
        setTimeout(() => {
          console.log('Attempting to restart polling...');
          this.bot.startPolling();
        }, 5000);
      }
    });
    
    this.setupListeners();
  }

  private setupListeners() {
    // Start command
    this.bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id;
      
      if (!userId) return;

      // Check if user exists, create if not
      if (msg.from) {
        await this.ensureUser(userId, msg.from);
      }

const miniAppUrl = 'https://teleshop.su/miniapp/5358ebd1-d90b-4c55-a0ff-f8840f8da283';
      
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [{ 
              text: 'Открыть магазин', 
              web_app: { url: miniAppUrl }
            }],
            [{ text: 'Мои заказы', callback_data: 'my_orders' }],
            [{ text: 'Привязать аккаунты', callback_data: 'link_accounts' }]
          ]
        }
      };

      this.bot.sendMessage(chatId, 
        `Добро пожаловать в бот для покупок!\n\n` +
        `Я помогу вам совершать покупки на Wildberries и Ozon.\n\n` +
        `Нажмите "Открыть магазин" для выбора товаров`,
        keyboard
      );
    });

    // Handle callback queries
    this.bot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      const userId = query.from.id;

      if (!chatId) return;

      switch (query.data) {
        case 'browse_products':
          await this.showProductCategories(chatId);
          break;
        case 'view_cart':
          await this.showCart(chatId, userId);
          break;
        case 'my_orders':
          const userUuid = await this.getUserIdByTelegramId(userId);
          if (userUuid) {
            await this.showUserOrders(chatId, userUuid);
          } else {
            this.bot.sendMessage(chatId, '❌ User not found. Please start the bot again.');
          }
          break;
        case 'link_accounts':
          await this.showLinkAccountsMenu(chatId);
          break;
        case 'link_wildberries':
          await this.startMarketplaceAuth(chatId, userId, 'wildberries');
          break;
        case 'link_ozon':
          await this.startMarketplaceAuth(chatId, userId, 'ozon');
          break;
      }

      // Handle product selection
      if (query.data?.startsWith('add_to_cart_')) {
        const productId = query.data.replace('add_to_cart_', '');
        await this.addToCart(chatId, userId, productId);
      } else if (query.data?.startsWith('category_')) {
        const category = query.data.replace('category_', '');
        await this.showProductsByCategory(chatId, category);
      } else if (query.data === 'clear_cart') {
        this.userCarts.delete(userId);
        this.bot.answerCallbackQuery(query.id, {
          text: '🗑 Корзина очищена',
          show_alert: false
        });
        await this.showCart(chatId, userId);
      } else if (query.data === '/start') {
        // Directly handle start command
        await this.handleStartCommand(chatId, userId, query.from);
      }

      this.bot.answerCallbackQuery(query.id);
    });

    // Handle phone/email input for authentication
    this.bot.on('message', async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id;
      const text = msg.text;

      if (!userId || !text || text.startsWith('/')) return;

      const session = this.authSessions.get(userId);
      if (!session) return;

      if (session.step === 'phone') {
        // User sent phone number
        await this.handlePhoneInput(chatId, userId, text, session);
      } else if (session.step === 'code') {
        // User sent verification code
        await this.handleCodeInput(chatId, userId, text, session);
      }
    });

    // Handle web app data (cart from miniapp)
    this.bot.on('web_app_data', async (msg) => {
      const chatId = msg.chat.id;
      const userId = msg.from?.id;
      
      if (!userId) return;

      try {
        const data = JSON.parse(msg.web_app_data?.data || '{}');
        
        if (data.action === 'checkout' && data.cart) {
          // Save cart for user
          this.userCarts.set(userId, data.cart);
          
          // Show checkout options
          const keyboard = {
            reply_markup: {
              inline_keyboard: [
                [{ text: '🟣 Checkout on Wildberries', callback_data: 'checkout_wildberries' }],
                [{ text: '🔵 Checkout on Ozon', callback_data: 'checkout_ozon' }]
              ]
            }
          };

          const cartSummary = data.cart.map((item: CartItem) => 
            `• ${item.product.name} x${item.quantity} - ${item.product.price * item.quantity}₽`
          ).join('\n');

          this.bot.sendMessage(chatId,
            `🛒 Your Cart:\n\n${cartSummary}\n\n` +
            `Total: ${data.cart.reduce((sum: number, item: CartItem) => sum + item.product.price * item.quantity, 0)}₽\n\n` +
            `Choose marketplace for checkout:`,
            keyboard
          );
        }
      } catch (error) {
        console.error('Error parsing web app data:', error);
      }
    });

    // Handle checkout
    this.bot.on('callback_query', async (query) => {
      const chatId = query.message?.chat.id;
      const userId = query.from.id;

      if (!chatId || !query.data?.startsWith('checkout_')) return;

      const marketplace = query.data.replace('checkout_', '') as 'wildberries' | 'ozon';
      const cart = this.userCarts.get(userId);

      if (!cart || cart.length === 0) {
        this.bot.sendMessage(chatId, '❌ Your cart is empty!');
        return;
      }

      // Get user UUID
      const userUuid = await this.getUserIdByTelegramId(userId);
      if (!userUuid) {
        this.bot.sendMessage(chatId, '❌ User not found. Please start the bot again.');
        return;
      }

      // Check if user has linked account for this marketplace
      const { data: account } = await supabase
        .from('marketplace_accounts')
        .select('*')
        .eq('user_id', userUuid)
        .eq('marketplace', marketplace)
        .eq('is_authenticated', true)
        .single();

      if (!account) {
        this.bot.sendMessage(chatId, 
          `❌ You need to link your ${marketplace} account first!\n\n` +
          `Use /start and click "Link Accounts" to connect your account.`
        );
        return;
      }

      // Process checkout
      await this.processCheckout(chatId, userUuid, marketplace, cart);
    });
  }

  private async ensureUser(telegramId: number, from: TelegramBot.User): Promise<string> {
    const { data: existingUser } = await supabase
      .from('users')
      .select('*')
      .eq('telegram_id', telegramId)
      .single();

    if (!existingUser) {
      const { data: newUser } = await supabase
        .from('users')
        .insert({
          telegram_id: telegramId,
          username: from.username,
          first_name: from.first_name,
          last_name: from.last_name
        })
        .select()
        .single();
      return newUser?.id || '';
    }
    return existingUser.id;
  }

  private async getUserIdByTelegramId(telegramId: number): Promise<string | null> {
    const { data: user } = await supabase
      .from('users')
      .select('id')
      .eq('telegram_id', telegramId)
      .single();
    
    return user?.id || null;
  }

  private async showUserOrders(chatId: number, userId: string) {
    const orders = await this.orderService.getUserOrders(userId);

    if (orders.length === 0) {
      this.bot.sendMessage(chatId, '📦 You have no orders yet.');
      return;
    }

    const ordersList = orders.map(order => 
      `📦 Order #${order.marketplace_order_id || order.id.slice(0, 8)}\n` +
      `Marketplace: ${order.marketplace}\n` +
      `Status: ${order.status}\n` +
      `Total: ${order.total_amount}₽\n` +
      `Date: ${new Date(order.created_at).toLocaleDateString()}`
    ).join('\n\n');

    this.bot.sendMessage(chatId, `📦 Your Orders:\n\n${ordersList}`);
  }

  private async showLinkAccountsMenu(chatId: number) {
    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🟣 Link Wildberries', callback_data: 'link_wildberries' }],
          [{ text: '🔵 Link Ozon', callback_data: 'link_ozon' }]
        ]
      }
    };

    this.bot.sendMessage(chatId, 
      '🔐 Link your marketplace accounts to enable automatic checkout:\n\n' +
      'Choose a marketplace:',
      keyboard
    );
  }

  private async startMarketplaceAuth(chatId: number, userId: number, marketplace: 'wildberries' | 'ozon') {
    const isMockMode = false; // Mock mode disabled - using real authentication
    
    // Initialize browser for real authentication
    if (!isMockMode) {
      console.log('Initializing browser for real authentication...');
      await this.browserService.init();
    }

    // Get user UUID
    const userUuid = await this.getUserIdByTelegramId(userId);
    if (!userUuid) {
      this.bot.sendMessage(chatId, '❌ User not found. Please start the bot again.');
      return;
    }

    // Create auth session
    this.authSessions.set(userId, {
      userId: userUuid,
      marketplace,
      step: 'phone'
    });

    const message = marketplace === 'wildberries' 
      ? '📱 Please enter your Wildberries phone number (format: +7XXXXXXXXXX):'
      : '📱 Please enter your Ozon phone number or email:';

    this.bot.sendMessage(chatId, message);
  }

  private async handlePhoneInput(chatId: number, userId: number, phoneOrEmail: string, session: AuthSession) {
    session.phoneOrEmail = phoneOrEmail;
    session.step = 'code';

    this.bot.sendMessage(chatId, '⏳ Logging in...');

    // Using real authentication with browser automation
    const isMockMode = false; // Mock mode disabled
    
    let success = false;
    
    if (isMockMode) {
      // Mock authentication - always succeed
      console.log(`Mock authentication for ${session.marketplace} with phone: ${phoneOrEmail}`);
      success = true;
      
      // Send a mock verification code message
      setTimeout(() => {
        this.bot.sendMessage(chatId, 
          `📱 [ТЕСТОВЫЙ РЕЖИМ]\n\n` +
          `Для тестирования используйте код: 123456\n\n` +
          `В реальном режиме код придет на ваш телефон.`
        );
      }, 1000);
    } else {
      // Real authentication with browser
      if (session.marketplace === 'wildberries') {
        success = await this.browserService.loginToWildberries(phoneOrEmail);
      } else {
        success = await this.browserService.loginToOzon(phoneOrEmail);
      }
    }

    if (success) {
      this.bot.sendMessage(chatId, '📲 Please enter the verification code:');
    } else {
      this.bot.sendMessage(chatId, '❌ Failed to login. Please try again.');
      this.authSessions.delete(userId);
      if (!isMockMode) {
        await this.browserService.close();
      }
    }
  }

  private async handleCodeInput(chatId: number, userId: number, code: string, session: AuthSession) {
    this.bot.sendMessage(chatId, '⏳ Verifying code...');

    // Using real code verification
    const isMockMode = false; // Mock mode disabled
    
    let success = false;
    
    if (isMockMode) {
      // In mock mode, accept code "123456"
      success = code === '123456';
      console.log(`Mock code verification: ${code} === '123456' ? ${success}`);
    } else {
      // Real authentication
      if (session.marketplace === 'wildberries') {
        success = await this.browserService.enterWildberriesCode(code);
      } else {
        success = await this.browserService.enterOzonCode(code);
      }
    }

    if (success) {
      // Save account info to database
      await supabase
        .from('marketplace_accounts')
        .upsert({
          user_id: session.userId,
          marketplace: session.marketplace,
          phone: session.phoneOrEmail?.includes('@') ? null : session.phoneOrEmail,
          email: session.phoneOrEmail?.includes('@') ? session.phoneOrEmail : null,
          is_authenticated: true
        });

      this.bot.sendMessage(chatId, 
        `✅ Successfully linked your ${session.marketplace} account!\n\n` +
        `You can now checkout automatically through the bot.`
      );
    } else {
      this.bot.sendMessage(chatId, '❌ Invalid verification code. Please check your phone and try again.');
    }

    // Clean up
    this.authSessions.delete(userId);
    if (!isMockMode) {
      await this.browserService.close();
    }
  }

  private async processCheckout(chatId: number, userId: string, marketplace: 'wildberries' | 'ozon', cart: CartItem[]) {
    this.bot.sendMessage(chatId, '⏳ Processing your order...');

    // Create order
    const order = await this.orderService.createOrder(userId, marketplace, cart);
    
    if (!order) {
      this.bot.sendMessage(chatId, '❌ Failed to create order. Please try again.');
      return;
    }

    // Process order (add to cart and checkout)
    const orderNumber = await this.orderService.processOrder(order.id, cart);

    if (orderNumber) {
      this.bot.sendMessage(chatId,
        `✅ Order placed successfully!\n\n` +
        `Order Number: ${orderNumber}\n` +
        `Marketplace: ${marketplace}\n\n` +
        `You can track your order status using /start → My Orders`
      );
      
      // Clear user's cart
      this.userCarts.delete(Number(userId));
    } else {
      this.bot.sendMessage(chatId, 
        '❌ Failed to process order. Please try again or contact support.'
      );
    }
  }

  private async showProductCategories(chatId: number) {
    // Get unique categories from products
    const { data: products } = await supabase
      .from('products')
      .select('category')
      .eq('in_stock', true);

    const categories = [...new Set(products?.map(p => p.category).filter(Boolean) || [])];
    
    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔍 Все товары', callback_data: 'category_all' }],
          ...categories.map(cat => 
            [{ text: cat, callback_data: `category_${cat}` }]
          ),
          [{ text: '↩️ Назад', callback_data: '/start' }]
        ]
      }
    };

    this.bot.sendMessage(chatId, '📂 Выберите категорию товаров:', keyboard);
  }

  private async showProductsByCategory(chatId: number, category: string) {
    let query = supabase
      .from('products')
      .select('*')
      .eq('in_stock', true)
      .limit(10);

    if (category !== 'all') {
      query = query.eq('category', category);
    }

    const { data: products } = await query;

    if (!products || products.length === 0) {
      this.bot.sendMessage(chatId, '😔 В этой категории пока нет товаров.');
      return;
    }

    for (const product of products) {
      const caption = 
        `🏷 **${product.name}**\n\n` +
        `💰 Цена: ${product.price}₽\n` +
        `📦 ${product.marketplace === 'wildberries' ? 'Wildberries' : 'Ozon'}\n` +
        (product.description ? `\n📝 ${product.description}\n` : '');

      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '🛒 Добавить в корзину', callback_data: `add_to_cart_${product.id}` }]
          ]
        }
      };

      if (product.image_url) {
        try {
          await this.bot.sendPhoto(chatId, product.image_url, {
            caption,
            parse_mode: 'Markdown',
            ...keyboard
          });
        } catch (error) {
          await this.bot.sendMessage(chatId, caption, {
            parse_mode: 'Markdown',
            ...keyboard
          });
        }
      } else {
        await this.bot.sendMessage(chatId, caption, {
          parse_mode: 'Markdown',
          ...keyboard
        });
      }
    }

    const backKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '↩️ К категориям', callback_data: 'browse_products' }],
          [{ text: '🛒 Корзина', callback_data: 'view_cart' }]
        ]
      }
    };

    this.bot.sendMessage(chatId, 'Выберите действие:', backKeyboard);
  }

  private async addToCart(chatId: number, userId: number, productId: string) {
    // Get product details
    const { data: product } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .single();

    if (!product) {
      this.bot.answerCallbackQuery(chatId.toString(), {
        text: '❌ Товар не найден',
        show_alert: true
      });
      return;
    }

    // Get current cart
    const cart = this.userCarts.get(userId) || [];
    
    // Check if product already in cart
    const existingItem = cart.find(item => item.product.id === productId);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({ product, quantity: 1 });
    }

    this.userCarts.set(userId, cart);

    this.bot.answerCallbackQuery(chatId.toString(), {
      text: `✅ ${product.name} добавлен в корзину`,
      show_alert: false
    });
  }

  private async handleStartCommand(chatId: number, userId: number, from: TelegramBot.User) {
    // Check if user exists, create if not
    await this.ensureUser(userId, from);

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🛍️ Выбрать товары', callback_data: 'browse_products' }],
          [{ text: '🛒 Моя корзина', callback_data: 'view_cart' }],
          [{ text: '📦 Мои заказы', callback_data: 'my_orders' }],
          [{ text: '🔐 Привязать аккаунты', callback_data: 'link_accounts' }]
        ]
      }
    };

    this.bot.sendMessage(chatId, 
      `🛍️ Добро пожаловать в бот для покупок!\n\n` +
      `Я помогу вам совершать покупки на Wildberries и Ozon.\n\n` +
      `• Выберите товары из каталога\n` +
      `• Добавьте их в корзину\n` +
      `• Оформите заказ через маркетплейс\n\n` +
      `Выберите действие:`,
      keyboard
    );
  }

  private async showCart(chatId: number, userId: number) {
    const cart = this.userCarts.get(userId) || [];

    if (cart.length === 0) {
      this.bot.sendMessage(chatId, 
        '🛒 Ваша корзина пуста\n\n' +
        'Выберите товары из каталога, чтобы добавить их в корзину.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '🛍️ К товарам', callback_data: 'browse_products' }]
            ]
          }
        }
      );
      return;
    }

    const cartItems = cart.map(item => 
      `• ${item.product.name} x${item.quantity} = ${item.product.price * item.quantity}₽`
    ).join('\n');

    const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🟣 Оформить на Wildberries', callback_data: 'checkout_wildberries' }],
          [{ text: '🔵 Оформить на Ozon', callback_data: 'checkout_ozon' }],
          [{ text: '🗑 Очистить корзину', callback_data: 'clear_cart' }],
          [{ text: '↩️ Назад', callback_data: '/start' }]
        ]
      }
    };

    this.bot.sendMessage(chatId,
      `🛒 **Ваша корзина:**\n\n${cartItems}\n\n` +
      `💰 **Итого:** ${total}₽`,
      { parse_mode: 'Markdown', ...keyboard }
    );
  }
}
