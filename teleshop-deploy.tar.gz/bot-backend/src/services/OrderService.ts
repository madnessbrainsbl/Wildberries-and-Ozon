import { supabase } from '../utils/supabase';
import { Order, OrderItem, CartItem } from '../types';
let BrowserService;

if (process.env.DISABLE_BROWSER === 'true') {
  BrowserService = require('./BrowserService.prod').BrowserService;
} else {
  BrowserService = require('./BrowserService').BrowserService;
}

export class OrderService {
  private browserService: BrowserService;

  constructor() {
    this.browserService = new BrowserService();
  }

  async createOrder(userId: string, marketplace: 'wildberries' | 'ozon', items: CartItem[]): Promise<Order | null> {
    try {
      // Calculate total amount
      const totalAmount = items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

      // Create order in database
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: userId,
          marketplace,
          status: 'pending',
          total_amount: totalAmount
        })
        .select()
        .single();

      if (orderError) throw orderError;

      // Create order items
      const orderItems = items.map(item => ({
        order_id: order.id,
        product_id: item.product.id,
        quantity: item.quantity,
        price: item.product.price
      }));

      const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (itemsError) throw itemsError;

      return order;
    } catch (error) {
      console.error('Error creating order:', error);
      return null;
    }
  }

  async processOrder(orderId: string, items: CartItem[]): Promise<string | null> {
    try {
      // Get order details
      const { data: order, error } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();

      if (error || !order) throw new Error('Order not found');

      // Update order status to processing
      await this.updateOrderStatus(orderId, 'processing');

      // Initialize browser
      await this.browserService.init();

      let orderNumber: string | null = null;

      // Process based on marketplace
      if (order.marketplace === 'wildberries') {
        // Add items to cart
        const cartSuccess = await this.browserService.addToCartWildberries(items);
        if (!cartSuccess) throw new Error('Failed to add items to cart');

        // Checkout
        orderNumber = await this.browserService.checkoutWildberries();
      } else if (order.marketplace === 'ozon') {
        // Add items to cart
        const cartSuccess = await this.browserService.addToCartOzon(items);
        if (!cartSuccess) throw new Error('Failed to add items to cart');

        // Checkout
        orderNumber = await this.browserService.checkoutOzon();
      }

      // Close browser
      await this.browserService.close();

      if (orderNumber) {
        // Update order with marketplace order number
        await supabase
          .from('orders')
          .update({
            marketplace_order_id: orderNumber,
            status: 'completed'
          })
          .eq('id', orderId);

        return orderNumber;
      } else {
        await this.updateOrderStatus(orderId, 'failed');
        return null;
      }
    } catch (error) {
      console.error('Error processing order:', error);
      await this.updateOrderStatus(orderId, 'failed');
      await this.browserService.close();
      return null;
    }
  }

  async updateOrderStatus(orderId: string, status: Order['status']) {
    await supabase
      .from('orders')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', orderId);
  }

  async getOrder(orderId: string): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_items (*)
      `)
      .eq('id', orderId)
      .single();

    if (error) {
      console.error('Error fetching order:', error);
      return null;
    }

    return data as Order;
  }

  async getUserOrders(userId: string): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select(`
        *,
        order_items (*)
      `)
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching user orders:', error);
      return [];
    }

    return data as Order[];
  }

  async trackOrder(orderId: string, marketplace: 'wildberries' | 'ozon', marketplaceOrderId: string) {
    // This would integrate with marketplace APIs to track order status
    // For now, just return the current status from database
    const order = await this.getOrder(orderId);
    return order?.status || 'unknown';
  }
}
