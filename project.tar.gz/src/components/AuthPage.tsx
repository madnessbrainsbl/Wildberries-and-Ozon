import React, { useState } from 'react'
import { Auth } from '@supabase/auth-ui-react'
import { ThemeSupa } from '@supabase/auth-ui-shared'
import { supabase } from '@/lib/supabase'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Store } from 'lucide-react'

export default function AuthPage() {
  const [view, setView] = useState<'sign_in' | 'sign_up'>('sign_in')

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Логотип */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-purple-700 rounded-xl flex items-center justify-center">
              <Store className="h-7 w-7 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-900">TS Partners</span>
          </div>
          <p className="text-gray-600">
            Платформа для управления Telegram магазинами
          </p>
        </div>

        {/* Форма авторизации */}
        <Card className="shadow-lg border-0">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-xl font-bold text-gray-900">
              {view === 'sign_in' ? 'Вход в систему' : 'Регистрация'}
            </CardTitle>
            <CardDescription className="text-gray-600">
              {view === 'sign_in' 
                ? 'Войдите в свой аккаунт' 
                : 'Создайте новый аккаунт'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Auth
              supabaseClient={supabase}
              view={view}
              appearance={{
                theme: ThemeSupa,
                variables: {
                  default: {
                    colors: {
                      brand: '#7C3AED',
                      brandAccent: '#6D28D9',
                      brandButtonText: 'white',
                      defaultButtonBackground: '#F8FAFC',
                      defaultButtonBackgroundHover: '#F1F5F9',
                      inputBackground: 'white',
                      inputBorder: '#E2E8F0',
                      inputBorderHover: '#CBD5E1',
                      inputBorderFocus: '#7C3AED',
                    },
                    borderWidths: {
                      buttonBorderWidth: '1px',
                      inputBorderWidth: '1px',
                    },
                    radii: {
                      borderRadiusButton: '8px',
                      buttonBorderRadius: '8px',
                      inputBorderRadius: '8px',
                    },
                  },
                },
                className: {
                  container: 'space-y-4',
                  button: 'w-full px-4 py-2 rounded-lg font-medium transition-colors',
                  input: 'w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500',
                  label: 'block text-sm font-medium text-gray-700 mb-1',
                  message: 'text-sm text-red-600 mt-1',
                },
              }}
              localization={{
                variables: {
                  sign_in: {
                    email_label: 'Email',
                    password_label: 'Пароль',
                    button_label: 'Войти',
                    loading_button_label: 'Вход...',
                    email_input_placeholder: 'Введите email',
                    password_input_placeholder: 'Введите пароль',
                  },
                  sign_up: {
                    email_label: 'Email',
                    password_label: 'Пароль',
                    button_label: 'Зарегистрироваться',
                    loading_button_label: 'Регистрация...',
                    email_input_placeholder: 'Введите email',
                    password_input_placeholder: 'Создайте пароль',
                    confirmation_text: 'Проверьте email для подтверждения',
                  },
                  forgotten_password: {
                    email_label: 'Email',
                    button_label: 'Восстановить',
                    loading_button_label: 'Отправка...',
                    link_text: 'Забыли пароль?',
                    email_input_placeholder: 'Введите email',
                    confirmation_text: 'Проверьте email для восстановления',
                  },
                },
              }}
              providers={[]}
              redirectTo={window.location.origin}
              onlyThirdPartyProviders={false}
              magicLink={false}
              showLinks={false}
            />
            
            <div className="mt-6 text-center">
              <button
                onClick={() => setView(view === 'sign_in' ? 'sign_up' : 'sign_in')}
                className="text-sm text-purple-600 hover:text-purple-700 font-medium"
              >
                {view === 'sign_in' 
                  ? 'Нет аккаунта? Зарегистрироваться' 
                  : 'Есть аккаунт? Войти'
                }
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Футер */}
        <div className="text-center mt-6 text-xs text-gray-500">
          © 2025 TS Partners. Все права защищены.
        </div>
      </div>
    </div>
  )
}