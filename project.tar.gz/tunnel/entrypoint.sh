#!/bin/bash

echo "🚀 Starting tunnel service..."

# Try localhost.run (no signup required)
echo "📡 Connecting to localhost.run..."
ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:frontend:5173 nokey@localhost.run
