# Deployment script for Windows PowerShell
$ServerIP = "82.146.40.171"
$ServerUser = "root"
$ServerPassword = "Alfa2000@"
$ProjectDir = "/opt/teleshop"

Write-Host "Starting deployment to VPS server..." -ForegroundColor Green

# Create secure string for password
$SecurePassword = ConvertTo-SecureString $ServerPassword -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($ServerUser, $SecurePassword)

# Install Posh-SSH module if not installed
if (!(Get-Module -ListAvailable -Name Posh-SSH)) {
    Write-Host "Installing Posh-SSH module..." -ForegroundColor Yellow
    Install-Module -Name Posh-SSH -Force -Scope CurrentUser
}

Import-Module Posh-SSH

# Create SSH session
Write-Host "Connecting to server..." -ForegroundColor Yellow
$SSHSession = New-SSHSession -ComputerName $ServerIP -Credential $Credential -AcceptKey -Force

if ($SSHSession) {
    Write-Host "Connected successfully!" -ForegroundColor Green
    
    # Execute commands on server
    Write-Host "Creating project directory..." -ForegroundColor Yellow
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "mkdir -p $ProjectDir"
    
    # Update system
    Write-Host "Updating system packages..." -ForegroundColor Yellow
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "apt-get update && apt-get upgrade -y" -TimeOut 300
    
    # Install Docker
    Write-Host "Installing Docker..." -ForegroundColor Yellow
    $dockerInstall = @"
apt-get install -y ca-certificates curl gnupg lsb-release
mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=\$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \$(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
"@
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command $dockerInstall -TimeOut 600
    
    # Install Node.js
    Write-Host "Installing Node.js..." -ForegroundColor Yellow
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && apt-get install -y nodejs" -TimeOut 300
    
    # Install Nginx
    Write-Host "Installing Nginx..." -ForegroundColor Yellow
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command "apt-get install -y nginx certbot python3-certbot-nginx" -TimeOut 300
    
    # Install Chrome for Puppeteer
    Write-Host "Installing Chrome..." -ForegroundColor Yellow
    $chromeInstall = @"
wget -q -O - https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -
echo "deb http://dl.google.com/linux/chrome/deb/ stable main" >> /etc/apt/sources.list.d/google.list
apt-get update
apt-get install -y google-chrome-stable
"@
    Invoke-SSHCommand -SessionId $SSHSession.SessionId -Command $chromeInstall -TimeOut 300
    
    Write-Host "Server setup completed!" -ForegroundColor Green
    
    # Close SSH session
    Remove-SSHSession -SessionId $SSHSession.SessionId
} else {
    Write-Host "Failed to connect to server!" -ForegroundColor Red
}

Write-Host "Next step: Upload project files using SCP" -ForegroundColor Yellow
